<?php

# Sample index.php file for fauria/lamp Docker image.
# To use your own website instead, please refer to the documentation:
# https://registry.hub.docker.com/u/fauria/lamp/

phpinfo();

?>
